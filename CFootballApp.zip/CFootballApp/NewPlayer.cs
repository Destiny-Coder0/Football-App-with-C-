using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballApp
{
    public class NewPlayer : Footballer, IFootballClub, IPosition
    {
        public string preferredFoot { get; set; }

        public NewPlayer(string name, string surname, int birthYear, string preferredFoot)
            :base(name, surname, birthYear) 
        { 
            this.preferredFoot = preferredFoot;
        } 

        public override void show()
        {
            Console.WriteLine("Name Surname " + this.name + " " + this.surname);
            getFootballClub();
            getPosition();
            Console.WriteLine("Preferred Foot: " + this.preferredFoot);
            Console.WriteLine("Age: " + getAge());
        }

        public void setPosition()
        {
            this.position = position;
        }

        public void getPosition()
        {
            Console.WriteLine("Position: " + this.position);
        }

        public void setFootballClub()
        {
            this.clubName = clubName;
        }

        public void getFootballClub()
        {
            Console.WriteLine("Club Name: " + this.clubName);
        }

        public override int getAge()
        {
            return DateTime.Now.Year - this.birthYear;
        }
    }
}
