using FootballApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main(string[] args)
    {
        NewPlayer player1 = new NewPlayer("Lionel", "Messi", 1990, "Left");
        player1.setFootballClub("Fenerbahçe");
        player1.setFootballClub("Forward");

        player1.show();

    }
}